<body class="bg-light">
  <div class="container p-6">
    <div class="row">
      <div class="col-lg-12 col-md-12 col-12 text-center">
        <!-- Page header -->
     
        <img src="<?= base_url() ?>assets/images/logo.svg" width="120px" alt="">

          <div class="border-bottom pb-4 mb-4">              
              <h3 class="mb-0 fw-bold mt-3">Kejaksaan Tinggi Kota Lhokseumawe</h3>             
            <p>Sistem Pengajuan pertemuan jaksa</p>
          </div>
       
      </div>
    </div>
    <div class="mt-5 text-center">
    <h1>Terima Kasih !!</h1>
    <p>Pengajuan anda telah dikirim <br>Silahkan cek email anda secara berkala untuk melihat balasan </p>
    </div>
  </div>