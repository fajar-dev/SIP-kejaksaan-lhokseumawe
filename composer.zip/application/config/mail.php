<?php
defined('BASEPATH') OR exit('No direct script access allowed');

      $config['mail'] = array(
        'protocol'  => 'smtp',
        'smtp_host' => 'ssl://smtp.googlemail.com',
        'smtp_user' => 'kejati.lsm@gmail.com',
        'smtp_pass' => 'yyoktfdkglxzlhar',
        'smtp_port' => 465,
        'mailtype'  => 'html',
        'charset'   => 'utf-8',
    );

    $config['addreas'] = 'kejati.lsm@gmail.com';
?>